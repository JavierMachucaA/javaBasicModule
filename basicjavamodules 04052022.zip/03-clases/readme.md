**_Enums_**:
https://www.baeldung.com/a-guide-to-java-enums

