package interfaces;

public interface Vehiculos {
    public void arrancar();
    public void parar();
}
