package interfaces;
// se genera la definicion
public interface Animal {
    public void emitirSonido();
}
