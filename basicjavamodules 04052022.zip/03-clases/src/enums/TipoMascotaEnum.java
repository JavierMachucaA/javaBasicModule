package enums;

public enum TipoMascotaEnum {
    ORDERED,
    READY,
    DELIVERED;
}