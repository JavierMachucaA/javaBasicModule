public class Pez {
    private String nombre;
    private String tipoPez;
    private Double tamano;

    public Pez() {
    }

    //faltan metodos
    // Generar to string
}
