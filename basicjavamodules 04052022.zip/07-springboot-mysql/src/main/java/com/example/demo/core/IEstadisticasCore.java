package com.example.demo.core;

public interface IEstadisticasCore {

    void ReporteUsuarios();
}
