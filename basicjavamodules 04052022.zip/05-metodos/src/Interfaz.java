import java.util.List;

public class Interfaz {
    private Integer columnas;
    private List<Integer> valores;

    public Interfaz() {
    }

    public Integer getColumnas() {
        return columnas;
    }

    public void setColumnas(Integer columnas) {
        this.columnas = columnas;
    }

    public List<Integer> getValores() {
        return valores;
    }

    public void setValores(List<Integer> valores) {
        this.valores = valores;
    }

}